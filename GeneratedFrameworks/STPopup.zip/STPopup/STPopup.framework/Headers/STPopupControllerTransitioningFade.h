//
//  STPopupControllerTransitioningFade.h
//  STPopup
//
//  Created by Kevin Lin on 18/8/16.
//  Copyright © 2016 Sth4Me. All rights reserved.
//

#import <STPopup/STPopupController.h>

@interface STPopupControllerTransitioningFade : NSObject <STPopupControllerTransitioning>

@end
